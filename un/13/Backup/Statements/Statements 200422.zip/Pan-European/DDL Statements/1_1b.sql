CREATE TABLE pan_european.table_1_1b (
  "country_iso" varchar,
  "row_name"    varchar,
  "forest_area_1990"        numeric,
  "forest_area_2000"        numeric,
  "forest_area_2005"        numeric,
  "forest_area_2010"        numeric,
  "forest_area_2015"        numeric,
  "forest_area_2020"        numeric,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_1b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);
