CREATE TABLE pan_european.table_1_2a (
  "country_iso" varchar,
  "row_name"    varchar,
  "total"        numeric,
  "coniferous"        numeric,
  "broadleaved"        numeric,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_2a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);
