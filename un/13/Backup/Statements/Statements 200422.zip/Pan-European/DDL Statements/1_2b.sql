CREATE TABLE pan_european.table_1_2b (
  "country_iso" varchar,
  "row_name"    varchar,
  "growing_stock_1990"        numeric,
  "growing_stock_2000"        numeric,
  "growing_stock_2005"        numeric,
  "growing_stock_2010"        numeric,
  "growing_stock_2015"        numeric,
  "growing_stock_2020"        numeric,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_2b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);
