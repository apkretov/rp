CREATE TABLE pan_european.table_1_3a2 (
  "country_iso"        varchar,
  "row_name"           varchar,
  "total_volume"       numeric,
  "regeneration_phase" numeric,
  "intermediate_phase" numeric,
  "mature_phase"       numeric,
  "unspecified"        numeric,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_3a2_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);
