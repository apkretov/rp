CREATE TABLE pan_european.table_1_3b (
  "country_iso"         varchar,
  "row_name"            varchar,
  "area"                numeric,
  "total_volume"        numeric,
  "less_or_equal_20_cm" numeric,
  "_21_40_cm"           numeric,
  "_41_60_cm"           numeric,
  "greater_60_cm"       numeric,
  "unspecified"         numeric,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_3b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);
