CREATE TABLE pan_european.table_1_4a
(
  "country_iso"  varchar,
  "row_name"     varchar,
  "above_ground" numeric,
  "below_ground" numeric,
  "deadwood"     numeric,
  "litter"       numeric,
  "soil_carbon"  numeric,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_4a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);
