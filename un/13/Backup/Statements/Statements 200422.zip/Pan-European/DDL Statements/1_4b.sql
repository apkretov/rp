CREATE TABLE pan_european.table_1_4b
(
  "country_iso"               varchar,
  "row_name"                  varchar,
  "total_carbon_stock_in_hwp" numeric,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_4b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);
