 CREATE TABLE pan_european.table_2_4 (
  	"country_iso" 				varchar,
  	"row_name"    				varchar,
  	"total_area_with_damage"     		numeric,
	"insects_and_disease"    		numeric,
	"wildlife_and_grazing"    		numeric,
	"forest_operations"    			numeric,
	"other"    				numeric,
	"primarily_damaged_by_abiotic_agents"	numeric,
	"primarily_damaged_by_fire_total" 	numeric,
	"of_which_human_induced"		numeric,
	"unspecified_mixed_damage"    		numeric,
	
	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_2_4_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)