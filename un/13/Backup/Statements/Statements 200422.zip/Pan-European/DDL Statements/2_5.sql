 CREATE TABLE pan_european.table_2_5 (
  	"country_iso" 				varchar,
  	"row_name"    				varchar,
  	"total_area_of_degraded_land"     	numeric,
	"grazing"    				numeric,
	"repeated_fires"    			numeric,
	"air_pollution"    			numeric,
	"desertification"    			numeric,
	"other_1"				numeric,
	"other_2" 				numeric,
	"other_3"				numeric,
	"unknown"    				numeric,
	"former_degraded_land_restored"  	numeric,
	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_2_5_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)