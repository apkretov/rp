 CREATE TABLE pan_european.table_3_1 (
  	"country_iso" 				varchar,
  	"row_name"    				varchar,
  	"gross_annual_increment"     		numeric,
	"natural_losses"    			numeric,
	"net_annual_increment"    		numeric,
	"fellings_total"    			numeric,
	"_of_which_of_natural_losses"  		numeric,
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_3_1_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)