 CREATE TABLE pan_european.table_4_2a (
  	"country_iso" 						    varchar,
  	"row_name"    						    varchar,
  	"natural_expansion_and_natural_regeneration"                numeric,
	"afforestation_and_regeneration_by_planting_and_or_seeding" numeric,
	"coppice"    						    numeric,
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_2a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)