 CREATE TABLE pan_european.table_4_2b (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"afforestation"     		numeric,
	"natural_expansion" 		numeric,
	"natural_regeneration"    	numeric,
	"planting_and_seeding" 		numeric,
	"coppice" 			numeric,
	
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_2b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)