 CREATE TABLE pan_european.table_4_3b (
  	"country_iso" 				 varchar,
  	"row_name"    				 varchar,
  	"naturally_established"    		 numeric,
	"naturalised_introduced_species" 	 numeric,
	"established_by_planting_and_or_seeding" numeric,
	"coppice"    				 numeric,
	"unknown_origin"    			 numeric,
	"native_species"    			 numeric,
	"introduced_species"			 numeric,
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_3b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)