 CREATE TABLE pan_european.table_4_4a (
  	"country_iso" 		varchar,
  	"row_name"    		varchar,
  	"total"    		numeric,
	"_of_which_invasive" 	numeric,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_4a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)