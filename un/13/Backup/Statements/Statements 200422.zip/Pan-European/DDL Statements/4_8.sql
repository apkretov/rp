 CREATE TABLE pan_european.table_4_8 (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"total_of_taxa"    		numeric,
	"vulnerable" 			numeric,
	"endangered"    		numeric,
	"critically_endangered" 	numeric,
	"extinct_in_the_wild"   	numeric,
	 	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_8_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)