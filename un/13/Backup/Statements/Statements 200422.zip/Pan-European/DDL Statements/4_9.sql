 CREATE TABLE pan_european.table_4_9 (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"mcpfe_class_1_1"    		numeric,
	"mcpfe_class_1_2" 		numeric,
	"mcpfe_class_1_3"    		numeric,
	"mcpfe_class_2" 		numeric,
		 	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_9_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)