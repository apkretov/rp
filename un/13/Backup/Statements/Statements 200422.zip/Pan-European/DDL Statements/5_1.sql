 CREATE TABLE pan_european.table_5_1 (
  	"country_iso" 						varchar,
  	"row_name"    						varchar,
  	"soil_water_and_other_forest_ecosystem_functions"    	numeric,
	"infrastructure_and_managed_natural_resources" 		numeric,
	"total"    						numeric,
	
		 	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_5_1_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)