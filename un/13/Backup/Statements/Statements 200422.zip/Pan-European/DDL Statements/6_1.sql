 CREATE TABLE pan_european.table_6_1 (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"total_forest_area"    		numeric,
	"total_number_of_holdings" 	numeric,
	"less_10_ha_area"    		numeric,
	"less_10_ha_number"    		numeric,
	"eleven_500_ha_area"    	numeric,
	"eleven_500_ha_number"    	numeric,
	"more_500_ha_area"    		numeric,
	"more_500_ha_number"    	numeric,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_1_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)