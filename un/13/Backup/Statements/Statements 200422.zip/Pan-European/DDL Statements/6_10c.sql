CREATE TABLE pan_european.table_6_10c (
  	"country_iso" 							   varchar,
  	"row_name"    							   varchar,
  	"forest_roads_and_paths_available_for_public_recreation"    	   numeric,
	"_of_which_designated_for_hiking_biking_cross_country_skiing_etc"  numeric,
	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_10c_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)