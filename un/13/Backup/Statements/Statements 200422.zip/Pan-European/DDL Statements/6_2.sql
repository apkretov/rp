 CREATE TABLE pan_european.table_6_2 (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"million_national_currency"    	numeric,
	"percent_of_total_gva" 		numeric,
	 
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_2_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)