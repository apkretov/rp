 CREATE TABLE pan_european.table_6_3 (
  	"country_iso" 					varchar,
  	"row_name"    					varchar,
  	"factor_income"    				numeric,
	"net_operating_surplus" 			numeric,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_3_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)