 CREATE TABLE pan_european.table_6_4a (
  	"country_iso" 					 varchar,
  	"row_name"    					 varchar,
  	"planting_of_trees_to_provide_regular_income"    numeric,
	"equipment_and_buildings" 			 numeric,
	"other_gross_fixed_capital_formation" 		 numeric,
	 "total" 					 numeric,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_4a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)