 CREATE TABLE pan_european.table_6_5a (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"total"    			numeric,
	"gender_male"    		numeric,
	"gender_female"    		numeric,	 
	"age_group_15_49"  		numeric,
	"age_group_50_plus"    		numeric,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_5a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)