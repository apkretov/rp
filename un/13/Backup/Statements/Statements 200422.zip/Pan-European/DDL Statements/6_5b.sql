CREATE TABLE pan_european.table_6_5b (
  	"country_iso" 		varchar,
  	"row_name"    		varchar,
  	"education_0_2"    	numeric,
	"education_3_4"    	numeric,	
	"education_5_6"    	numeric,
	"employees"    		numeric,
	"self_employed"    	numeric,	
	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_5b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)