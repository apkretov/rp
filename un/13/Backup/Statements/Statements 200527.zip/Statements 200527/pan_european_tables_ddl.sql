DROP TABLE IF EXISTS pan_european.table_1_1a;
CREATE TABLE pan_european.table_1_1a (
  "country_iso" varchar,
  "row_name"    varchar,
  "area"        double precision,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_1a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_1_1b;
CREATE TABLE pan_european.table_1_1b (
  "country_iso" varchar,
  "row_name"    varchar,
  "forest_area_1990"        double precision,
  "forest_area_2000"        double precision,
  "forest_area_2005"        double precision,
  "forest_area_2010"        double precision,
  "forest_area_2015"        double precision,
  "forest_area_2020"        double precision,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_1b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_1_2a;
CREATE TABLE pan_european.table_1_2a (
  "country_iso" varchar,
  "row_name"    varchar,
  "total"        double precision,
  "coniferous"        double precision,
  "broadleaved"        double precision,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_2a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_1_2b;
CREATE TABLE pan_european.table_1_2b (
  "country_iso" varchar,
  "row_name"    varchar,
  "growing_stock_1990"        double precision,
  "growing_stock_2000"        double precision,
  "growing_stock_2005"        double precision,
  "growing_stock_2010"        double precision,
  "growing_stock_2015"        double precision,
  "growing_stock_2020"        double precision,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_2b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_1_2c;
CREATE TABLE pan_european.table_1_2c (
  "country_iso" varchar,
  "row_name"    varchar,
  "scientific_name"    varchar,
  "common_name"    varchar,
  "growing_stock_in_forest_1990"        double precision,
  "growing_stock_in_forest_2000"        double precision,
  "growing_stock_in_forest_2005"        double precision,
  "growing_stock_in_forest_2010"        double precision,
  "growing_stock_in_forest_2015"        double precision,
  "growing_stock_in_forest_2020"        double precision,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_2c_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_1_3a1;
CREATE TABLE pan_european.table_1_3a1 (
  "country_iso"        varchar,
  "row_name"           varchar,
  "total_area"         double precision,
  "regeneration_phase" double precision,
  "intermediate_phase" double precision,
  "mature_phase"       double precision,
  "unspecified"        double precision,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_3a1_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_1_3a2;
CREATE TABLE pan_european.table_1_3a2 (
  "country_iso"        varchar,
  "row_name"           varchar,
  "total_volume"       double precision,
  "regeneration_phase" double precision,
  "intermediate_phase" double precision,
  "mature_phase"       double precision,
  "unspecified"        double precision,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_3a2_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_1_3b;
CREATE TABLE pan_european.table_1_3b (
  "country_iso"         varchar,
  "row_name"            varchar,
  "area"                double precision,
  "total_volume"        double precision,
  "less_or_equal_20_cm" double precision,
  "_21_40_cm"           double precision,
  "_41_60_cm"           double precision,
  "greater_60_cm"       double precision,
  "unspecified"         double precision,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_3b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_1_4a;
CREATE TABLE pan_european.table_1_4a
(
  "country_iso"  varchar,
  "row_name"     varchar,
  "above_ground" double precision,
  "below_ground" double precision,
  "deadwood"     double precision,
  "litter"       double precision,
  "soil_carbon"  double precision,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_4a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_1_4b;
CREATE TABLE pan_european.table_1_4b
(
  "country_iso"               varchar,
  "row_name"                  varchar,
  "total_carbon_stock_in_hwp" double precision,
  PRIMARY KEY (country_iso, row_name),
  CONSTRAINT pan_european_table_1_4b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_2_4;
CREATE TABLE pan_european.table_2_4 (
  	"country_iso" 				varchar,
  	"row_name"    				varchar,
  	"total_area_with_damage"     		double precision,
	"insects_and_disease"    		double precision,
	"wildlife_and_grazing"    		double precision,
	"forest_operations"    			double precision,
	"other"    				double precision,
	"primarily_damaged_by_abiotic_agents"	double precision,
	"primarily_damaged_by_fire_total" 	double precision,
	"of_which_human_induced"		double precision,
	"unspecified_mixed_damage"    		double precision,
	
	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_2_4_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_2_5;
CREATE TABLE pan_european.table_2_5 (
  	"country_iso" 				varchar,
  	"row_name"    				varchar,
  	"total_area_of_degraded_land"     	double precision,
	"grazing"    				double precision,
	"repeated_fires"    			double precision,
	"air_pollution"    			double precision,
	"desertification"    			double precision,
	"other_1"				double precision,
	"other_2" 				double precision,
	"other_3"				double precision,
	"unknown"    				double precision,
	"former_degraded_land_restored"  	double precision,
	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_2_5_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_2_5oth;
CREATE TABLE pan_european.table_2_5oth (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
	"other_1"				varchar,
	"other_2" 				varchar,
	"other_3"				varchar,
	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_2_5oth_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_3_1;
CREATE TABLE pan_european.table_3_1 (
  	"country_iso" 				varchar,
  	"row_name"    				varchar,
  	"gross_annual_increment"     		double precision,
	"natural_losses"    			double precision,
	"net_annual_increment"    		double precision,
	"fellings_total"    			double precision,
	"_of_which_of_natural_losses"  		double precision,
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_3_1_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_3_2;
CREATE TABLE pan_european.table_3_2 (
  	"country_iso" 				varchar,
  	"row_name"    				varchar,
  	"total_volume"     			double precision,
	"industrial_roundwood_volume"    	double precision,
	"industrial_roundwood_market_value"    	double precision,
	"woodfuel_volume"    			double precision,
	"woodfuel_market_value"    		double precision,
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_3_2_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_3_3;
CREATE TABLE pan_european.table_3_3 (
  	"country_iso" 								 varchar,
  	"row_name"    								 varchar,
  	"name_of_groups_of_product" 				 		 varchar,
	"key_species"    							 varchar,
	"total_harvested_non_wood_goods_unit"  		 			 varchar,
	"total_harvested_non_wood_goods_quantity"    				 double precision,
	"market_value_1000_national_currency"  		 			 double precision,
	"nwfp_category"   							 double precision,
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_3_3_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_3_4;
CREATE TABLE pan_european.table_3_4 (
  	"country_iso" 						varchar,
  	"row_name"    						varchar,
  	"name_of_service_product" 				varchar,
	"unit"    						varchar,
	"service_provision_amount_of_service_product"    	double precision,
	"service_provision_value_1000_national_currency" 	double precision,
	"forest_service_category"   				double precision,
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_3_4_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_4_1;
CREATE TABLE pan_european.table_4_1 (
  	"country_iso" 						varchar,
  	"row_name"    						varchar,
  	"area_with_number_of_tree_species_occurring_1"    	double precision,
	"area_with_number_of_tree_species_occurring_2_3"    	double precision,
	"area_with_number_of_tree_species_occurring_4_5"    	double precision,
	"area_with_number_of_tree_species_occurring_6_pl"    	double precision,
	
	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_1_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_4_2a;
CREATE TABLE pan_european.table_4_2a (
  	"country_iso" 						    varchar,
  	"row_name"    						    varchar,
  	"natural_expansion_and_natural_regeneration"                double precision,
	"afforestation_and_regeneration_by_planting_and_or_seeding" double precision,
	"coppice"    						    double precision,
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_2a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_4_2b;
CREATE TABLE pan_european.table_4_2b (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"afforestation"     		double precision,
	"natural_expansion" 		double precision,
	"natural_regeneration"    	double precision,
	"planting_and_seeding" 		double precision,
	"coppice" 			double precision,
	
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_2b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_4_3a;
CREATE TABLE pan_european.table_4_3a (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"undisturbed_by_man"    	double precision,
	"semi_natural" 			double precision,
	"plantations"    		double precision,
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_3a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_4_3b;
CREATE TABLE pan_european.table_4_3b (
  	"country_iso" 				 varchar,
  	"row_name"    				 varchar,
  	"naturally_established"    		 double precision,
	"naturalised_introduced_species" 	 double precision,
	"established_by_planting_and_or_seeding" double precision,
	"coppice"    				 double precision,
	"unknown_origin"    			 double precision,
	"native_species"    			 double precision,
	"introduced_species"			 double precision,
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_3b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_4_4a;
CREATE TABLE pan_european.table_4_4a (
  	"country_iso" 		varchar,
  	"row_name"    		varchar,
  	"total"    		double precision,
	"_of_which_invasive" 	double precision,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_4a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_4_4b;
CREATE TABLE pan_european.table_4_4b (
  	"country_iso" 							varchar,
  	"row_name"    							varchar,
  	"scientific_name_of_introduced_tree_species" 			varchar,
	"forest_area_occupied_2005"    					double precision,
	"forest_area_occupied_2010" 					double precision,
	"forest_area_occupied_2015"   					double precision,
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_4b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_4_4c;
CREATE TABLE pan_european.table_4_4c (
  	"country_iso" 						varchar,
  	"row_name"    						varchar,
  	"scientific_name_of_invasive_tree_species" 		varchar,
	"forest_area_affected_2005"    				double precision,
	"forest_area_affected_2010" 				double precision,
	"forest_area_affected_2015"   				double precision,
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_4c_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_4_5a;
CREATE TABLE pan_european.table_4_5a (
  	country_iso 	varchar,
  	row_name  	varchar,
  	total    	double precision,
	standing 	double precision,
	lying 		double precision,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_5a_country_fk FOREIGN KEY (country_iso) REFERENCES country (country_iso) ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_4_5b;
CREATE TABLE pan_european.table_4_5b (
  	"country_iso" 	varchar,
  	"row_name"  	varchar,
  	"total"    	double precision,
	"standing" 	double precision,
	"lying" 	double precision,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_5b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_4_8;
CREATE TABLE pan_european.table_4_8 (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"total_of_taxa"    		double precision,
	"vulnerable" 			double precision,
	"endangered"    		double precision,
	"critically_endangered" 	double precision,
	"extinct_in_the_wild"   	double precision,
	 	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_8_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_4_9;
CREATE TABLE pan_european.table_4_9 (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"mcpfe_class_1_1"    		double precision,
	"mcpfe_class_1_2" 		double precision,
	"mcpfe_class_1_3"    		double precision,
	"mcpfe_class_2" 		double precision,
		 	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_4_9_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_5_1;
CREATE TABLE pan_european.table_5_1 (
  	"country_iso" 						varchar,
  	"row_name"    						varchar,
  	"soil_water_and_other_forest_ecosystem_functions"    	double precision,
	"infrastructure_and_managed_natural_resources" 		double precision,
	"total"    						double precision,
	
		 	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_5_1_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_1;
CREATE TABLE pan_european.table_6_1 (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"total_forest_area"    		double precision,
	"total_number_of_holdings" 	double precision,
	"less_10_ha_area"    		double precision,
	"less_10_ha_number"    		double precision,
	"_11_500_ha_area"    	double precision,
	"_11_500_ha_number"    	double precision,
	"more_500_ha_area"    		double precision,
	"more_500_ha_number"    	double precision,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_1_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_2;
CREATE TABLE pan_european.table_6_2 (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"million_national_currency"    	double precision,
	"percent_of_total_gva" 		double precision,
	 
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_2_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_3;
CREATE TABLE pan_european.table_6_3 (
  	"country_iso" 					varchar,
  	"row_name"    					varchar,
  	"factor_income"    				double precision,
	"net_operating_surplus" 			double precision,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_3_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_4a;
CREATE TABLE pan_european.table_6_4a (
  	"country_iso" 					 varchar,
  	"row_name"    					 varchar,
  	"planting_of_trees_to_provide_regular_income"    double precision,
	"equipment_and_buildings" 			 double precision,
	"other_gross_fixed_capital_formation" 		 double precision,
	 "total" 					 double precision,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_4a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_4b;
CREATE TABLE pan_european.table_6_4b (
  	"country_iso" 		       varchar,
  	"row_name"    		       varchar,
  	"fixed_capital_consumption"    double precision,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_4b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_4c;
CREATE TABLE pan_european.table_6_4c (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"capital_transfers"    		double precision,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_4c_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_5a;
CREATE TABLE pan_european.table_6_5a (
  	"country_iso" 			varchar,
  	"row_name"    			varchar,
  	"total"    			double precision,
	"gender_male"    		double precision,
	"gender_female"    		double precision,	 
	"age_group_15_49"  		double precision,
	"age_group_50_plus"    		double precision,
	 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_5a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_5b;
CREATE TABLE pan_european.table_6_5b (
  	"country_iso" 		varchar,
  	"row_name"    		varchar,
  	"education_0_2"    	double precision,
	"education_3_4"    	double precision,	
	"education_5_6"    	double precision,
	"employees"    		double precision,
	"self_employed"    	double precision,	
	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_5b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_6;
CREATE TABLE pan_european.table_6_6 (
  	"country_iso" 							varchar,
  	"row_name"    							varchar,
  	"fatal_occupational_accidents_number"    			double precision,
	"fatal_occupational_accidents_per_1000_workers"    		double precision,
	"non_fatal_occupational_accidents_number"    			double precision,	 
	"non_fatal_occupational_accidents_per_1000_workers" 		double precision,
		 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_6_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_7;
CREATE TABLE pan_european.table_6_7 (
  	"country_iso" 				varchar,
  	"row_name"    				varchar,
  	"n_a"     				double precision,

		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_7_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_8;
CREATE TABLE pan_european.table_6_8 (
  	"country_iso" 		    varchar,
  	"row_name"    	            varchar,
  	"quantity_million_m3_rwe"   double precision,
	"value_million_euro_ecu"    double precision,

		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_8_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_9;
CREATE TABLE pan_european.table_6_9 (
  	"country_iso" 		    		 varchar,
  	"row_name"    	            		 varchar,
  	"tj_2007"   				 double precision,
	"_1000_metric_tonnes_dry_matter_2007"    double precision,
	"tj_2009"    				 double precision,
	"_1000_metric_tonnes_dry_matter_2009"    double precision,
	"tj_2011"    				 double precision,
	"_1000_metric_tonnes_dry_matter_2011"    double precision,
	"tj_2013"    				 double precision,
	"_1000_metric_tonnes_dry_matter_2013"    double precision,
	"tj_2015"    				 double precision,
	"_1000_metric_tonnes_dry_matter_2015"    double precision,

		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_9_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_10a;
CREATE TABLE pan_european.table_6_10a (
  	"country_iso" 						    varchar,
  	"row_name"    						    varchar,
  	"area_available_for_public_recreation_total"    	    double precision,
	"area_available_for_public_recreation_percent"    	    double precision,
	"area_designated_or_managed_for_public_recreation_total"    double precision,	 
	"area_designated_or_managed_for_public_recreation_percent"  double precision,
		 
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_10a_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_10b;
CREATE TABLE pan_european.table_6_10b (
  	"country_iso" 							varchar,
  	"row_name"    							varchar,
  	"area_available_for_public_recreation"    			double precision,
	"area_designated_and_or_managed_for_public_recreation"    	double precision,
	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_10b_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_10c;
CREATE TABLE pan_european.table_6_10c (
  	"country_iso" 							   varchar,
  	"row_name"    							   varchar,
  	"forest_roads_and_paths_available_for_public_recreation"    	   double precision,
	"_of_which_designated_for_hiking_biking_cross_country_skiing_etc"  double precision,
	
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_10c_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
);

DROP TABLE IF EXISTS pan_european.table_6_10d;
CREATE TABLE pan_european.table_6_10d (
  	"country_iso" 				varchar,
  	"row_name"    				varchar,
  	"facility" 				varchar,
	"measurement_unit" 			varchar,
	"extent_multiplicity"  			double precision,
	"facility_category" 			double precision,
	
		
  	PRIMARY KEY (country_iso, row_name),
	CONSTRAINT pan_european_table_6_10d_country_fk FOREIGN KEY (country_iso) REFERENCES "country" ("country_iso") ON DELETE CASCADE
)